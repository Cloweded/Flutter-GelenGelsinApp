import 'package:flutter/material.dart';

class ChatsPage extends StatelessWidget {
  const ChatsPage({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null, // Set the app bar to null
      body: Container(
        color: Colors.grey[200], // Set the background color to light gray
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: ListView(
            children: [
              buildRow("assets/images/p1.jpg", "Behlül",
                  "Heyyo Waasssuuupp brooo:):):)"),
              buildRow("assets/images/p2.jpg", "Bihter", "NEREDE KALDINNN "),
              buildRow("assets/images/p3.jpg", "Adnan",
                  "O SENİN YENGEN YENGEN!!!!!!"),
              buildRow("assets/images/p4.jpg", "Ragnar", "WHO WANT TO BE KİNG"),
              buildRow(
                  "assets/images/p5.jpg", "Lagartha", "Where are you ragnar"),
              // Add more rows as needed
            ],
          ),
        ),
      ),
    );
  }

  Widget buildRow(String imagePath, String name, String text) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            name,
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          SizedBox(height: 5),
          Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(50),
                child: Image.asset(
                  imagePath,
                  width: 100,
                  height: 100, // Set a fixed height for all images
                  fit: BoxFit.cover,
                ),
              ),
              SizedBox(width: 10),
              Text(text),
            ],
          ),
        ],
      ),
    );
  }
}
