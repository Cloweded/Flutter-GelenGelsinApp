import 'package:flutter/material.dart';

class StatusPage extends StatelessWidget {
  const StatusPage({Key? key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null, // Set the app bar to null
      body: Container(
        color: Colors.grey[200], // Set the background color to light gray
        padding: const EdgeInsets.all(20.0),
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            buildProfile(
              "assets/images/ben.jpg",
              "Ömer Yiğit Kasap",
              "GelenGelsinApp Developer",
            ),
          ],
        ),
      ),
    );
  }

  Widget buildProfile(String imagePath, String name, String status) {
    return Column(
      children: [
        Expanded(
          child: ClipRRect(
            borderRadius:
                BorderRadius.circular(20), // Adjust the border radius as needed
            child: Image.asset(
              imagePath,
              fit: BoxFit.cover,
            ),
          ),
        ),
        Container(
          color: Colors.white,
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              SizedBox(height: 10),
              Text(
                name,
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                ),
              ),
              SizedBox(height: 5),
              Text(
                status,
                style: TextStyle(
                  color: Colors.grey,
                ),
              ),
              SizedBox(height: 20),
              // Additional content on the right side
              Text(
                "Additional Information",
                style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
              SizedBox(height: 10),
              Text(
                "Gelen gelsin dünya şirketi adına çalışan biri "
                "Dünya bu kadar kalabalıksa peki biz neden yanlızız usta :(:(",
                style: TextStyle(
                  color: Colors.grey,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
