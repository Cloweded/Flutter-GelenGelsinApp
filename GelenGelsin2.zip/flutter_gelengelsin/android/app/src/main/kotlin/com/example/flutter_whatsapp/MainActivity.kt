package com.example.flutter_whatsapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
